#include <HX711_ADC.h>
#include <HTTPClient.h>
#include <ThingSpeak.h>
#include <WiFi.h>
#include <ESP32Servo.h>
#include <Arduino.h>
#include <MD_Parola.h>
#include <MD_MAX72xx.h>

#if defined(ESP8266)|| defined(ESP32) || defined(AVR)
#include <EEPROM.h>
#endif

#define HARDWARE_TYPE MD_MAX72XX::GENERIC_HW
// #define HARDWARE_TYPE MD_MAX72XX::FC16_HW
#define MAX_DEVICES 1// 4 blocks
#define CS_PIN 5
// create an instance of the MD_Parola class
MD_Parola ledMatrix = MD_Parola(HARDWARE_TYPE, CS_PIN, MAX_DEVICES);

#define SERVO_PIN 26 // ESP32 pin GPIO26 connected to servo motor
Servo servoMotor;

bool isFirstTime = true;

//pins:
const int HX711_dout = 21; //mcu > HX711 dout pin
const int HX711_sck = 19; //mcu > HX711 sck pin

// Temporizador
uint32_t startMillis;
const uint16_t timerDuration = 10000;

// Credenciales WiFi
const char *ssid = "iPhone de Daniela"; // Tu SSID
const char *password = "1080969Dan"; // Tu contraseña del SSID
WiFiClient client;

// ThingSpeak
uint32_t channelNumber = 2536953; // Tu ID de canal en ThingSpeak
const char *writeAPIKey = "RGAH37WLS221B7AD"; // Tu API key de escritura en ThingSpeak

//HX711 constructor:
HX711_ADC LoadCell(HX711_dout, HX711_sck);

const int calVal_eepromAdress = 0;
unsigned long t = 0;

void changeSavedCalFactor() {
  float oldCalibrationValue = LoadCell.getCalFactor();
  boolean _resume = false;
  Serial.println("***");
  Serial.print("Current value is: ");
  Serial.println(oldCalibrationValue);
  Serial.println("Now, send the new value from serial monitor, i.e. 696.0");
  float newCalibrationValue;
  while (_resume == false) {
    if (Serial.available() > 0) {
      newCalibrationValue = Serial.parseFloat();
      if (newCalibrationValue != 0) {
        Serial.print("New calibration value is: ");
        Serial.println(newCalibrationValue);
        LoadCell.setCalFactor(newCalibrationValue);
        _resume = true;
      }
    }
  }
  _resume = false;
  Serial.print("Save this value to EEPROM adress ");
  Serial.print(calVal_eepromAdress);
  Serial.println("? y/n");
  while (_resume == false) {
    if (Serial.available() > 0) {
      char inByte = Serial.read();
      if (inByte == 'y') {
#if defined(ESP8266)|| defined(ESP32)
        EEPROM.begin(512);
#endif
        EEPROM.put(calVal_eepromAdress, newCalibrationValue);
#if defined(ESP8266)|| defined(ESP32)
        EEPROM.commit();
#endif
        EEPROM.get(calVal_eepromAdress, newCalibrationValue);
        Serial.print("Value ");
        Serial.print(newCalibrationValue);
        Serial.print(" saved to EEPROM address: ");
        Serial.println(calVal_eepromAdress);
        _resume = true;
      }
      else if (inByte == 'n') {
        Serial.println("Value not saved to EEPROM");
        _resume = true;
      }
    }
  }
  Serial.println("End change calibration value");
  Serial.println("***");
}

void calibrate() {
  Serial.println("***");
  Serial.println("Start calibration:");
  Serial.println("Place the load cell an a level stable surface.");
  Serial.println("Remove any load applied to the load cell.");
  Serial.println("Send 't' from serial monitor to set the tare offset.");

  boolean _resume = false;
  while (_resume == false) {
    LoadCell.update();
    if (Serial.available() > 0) {
      if (Serial.available() > 0) {
        char inByte = Serial.read();
        if (inByte == 't') LoadCell.tareNoDelay();
      }
    }
    if (LoadCell.getTareStatus() == true) {
      Serial.println("Tare complete");
      _resume = true;
    }
  }

  Serial.println("Now, place your known mass on the loadcell.");
  Serial.println("Then send the weight of this mass (i.e. 100.0) from serial monitor.");

  float known_mass = 0;
  _resume = false;
  while (_resume == false) {
    LoadCell.update();
    if (Serial.available() > 0) {
      known_mass = Serial.parseFloat();
      if (known_mass != 0) {
        Serial.print("Known mass is: ");
        Serial.println(known_mass);
        _resume = true;
      }
    }
  }

  LoadCell.refreshDataSet(); //refresh the dataset to be sure that the known mass is measured correct
  float newCalibrationValue = LoadCell.getNewCalibration(known_mass); //get the new calibration value

  Serial.print("New calibration value has been set to: ");
  Serial.print(newCalibrationValue);
  Serial.println(", use this as calibration value (calFactor) in your project sketch.");
  Serial.print("Save this value to EEPROM adress ");
  Serial.print(calVal_eepromAdress);
  Serial.println("? y/n");

  _resume = false;
  while (_resume == false) {
    if (Serial.available() > 0) {
      char inByte = Serial.read();
      if (inByte == 'y') {
#if defined(ESP8266)|| defined(ESP32)
        EEPROM.begin(512);
#endif
        EEPROM.put(calVal_eepromAdress, newCalibrationValue);
#if defined(ESP8266)|| defined(ESP32)
        EEPROM.commit();
#endif
        EEPROM.get(calVal_eepromAdress, newCalibrationValue);
        Serial.print("Value ");
        Serial.print(newCalibrationValue);
        Serial.print(" saved to EEPROM address: ");
        Serial.println(calVal_eepromAdress);
        _resume = true;

      }
      else if (inByte == 'n') {
        Serial.println("Value not saved to EEPROM");
        _resume = true;
      }
    }
  }

  Serial.println("End calibration");
  Serial.println("***");
  Serial.println("To re-calibrate, send 'r' from serial monitor.");
  Serial.println("For manual edit of the calibration value, send 'c' from serial monitor.");
  Serial.println("***");
}

void connectWiFi() {
    Serial.print("Esperando WiFi...");
    WiFi.begin(ssid, password);
    while (WiFi.status() != WL_CONNECTED) {
        Serial.print(".");
        delay(500);
    }
    Serial.println("\nWiFi Conectado");
    Serial.println("Dirección IP: " + WiFi.localIP().toString());
}

void setup() {
  Serial.begin(9600); delay(10);
  Serial.println();
  Serial.println("Starting...");

  ledMatrix.begin();         // initialize the LED Matrix
  ledMatrix.setIntensity(1); // set the brightness of the LED matrix display (from 0 to 15)
  ledMatrix.displayClear();  // clear LED matrix display

  servoMotor.attach(SERVO_PIN);  // attaches the servo on ESP32 pin


  ThingSpeak.begin(client); // Inicializa ThingSpeak
  // connectWiFi();
  startMillis = millis(); // Inicia el temporizador

  LoadCell.begin();
  //LoadCell.setReverseOutput(); //uncomment to turn a negative output value to positive
  unsigned long stabilizingtime = 2000; // preciscion right after power-up can be improved by adding a few seconds of stabilizing time
  boolean _tare = true; //set this to false if you don't want tare to be performed in the next step
  LoadCell.start(stabilizingtime, _tare);
  if (LoadCell.getTareTimeoutFlag() || LoadCell.getSignalTimeoutFlag()) {
    Serial.println("Timeout, check MCU>HX711 wiring and pin designations");
    while (1);
  }
  else {
    LoadCell.setCalFactor(1.0); // user set calibration value (float), initial value 1.0 may be used for this sketch
    Serial.println("Startup is complete");
  }
  while (!LoadCell.update());
  calibrate(); //start calibration procedure
}

void loop() {
  static boolean newDataReady = 0;
  const int serialPrintInterval = 0; //increase value to slow down serial print activity

  // check for new data/start next conversion:
  if (LoadCell.update()) newDataReady = true;

  // get smoothed value from the dataset:
  if (newDataReady) {
    if (millis() > t + serialPrintInterval) {

      // if (WiFi.status() != WL_CONNECTED) {
      //   Serial.println("No se detectó conexión a Internet");
      //   connectWiFi();
      // }


      float i = LoadCell.getData();
      Serial.print("Load_cell output val: ");
      Serial.println(i);
      // ThingSpeak.setField(1, i);
      // int code = ThingSpeak.writeFields(channelNumber, writeAPIKey);
      // if (code == 200) {
      //     Serial.println("Canal de ThingSpeak actualizado correctamente.");
      // } else {
      //     Serial.println("Error al actualizar canal. Código HTTP: " + String(code));
      // }

      if (i > 0.5)
      {
         isFirstTime = true; 
      }
      

      if(i < 0.5 && isFirstTime){

        digitalWrite(5,HIGH);
        Serial.println("Led apagado");
        delay(1000);
        for (int pos = 0; pos <= 180; pos += 1) {
        // in steps of 1 degree
        servoMotor.write(pos);
        delay(5); // waits 15ms to reach the position

        }

        // rotates from 180 degrees to 0 degrees
        for (int pos = 180; pos >= 0; pos -= 1) {
          servoMotor.write(pos);
          delay(5); // waits 15ms to reach the position
        }

        isFirstTime = false; // Set the flag to false after the first execution
        digitalWrite(5,LOW);

      }

      newDataReady = 0;
      t = millis();
    }
  }

  // receive command from serial terminal
  if (Serial.available() > 0) {
    char inByte = Serial.read();
    if (inByte == 't') LoadCell.tareNoDelay(); //tare
    else if (inByte == 'r') calibrate(); //calibrate
    else if (inByte == 'c') changeSavedCalFactor(); //edit calibration value manually
    else if (inByte == 'a') LoadCell.powerDown(); //edit calibration value manually
    else if (inByte == 'd') LoadCell.powerUp(); //edit calibration value manually
  }

  // check if last tare operation is complete
  if (LoadCell.getTareStatus() == true) {
    Serial.println("Tare complete");
  }

}

