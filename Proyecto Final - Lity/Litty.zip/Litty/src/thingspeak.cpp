// #include <DHT.h>
// #include <HTTPClient.h>
// #include <ThingSpeak.h>
// #include <WiFi.h>

// // Estructura de datos de temperatura
// struct TemperatureData {
//     float dht; // en Celsius
//     String getAllTemperatureData() {
//         return "\nDHT: " + (String)dht + "*C";
//     }
// };

// // dht11
// const uint8_t dhtPin = 15; // Pin para el sensor de temperatura
// const uint8_t dhtType = DHT11;
// DHT dht(dhtPin, dhtType);

// // Datos de temperatura
// TemperatureData temperatureData;

// // Temporizador
// uint32_t startMillis;
// const uint16_t timerDuration = 10000;

// // Credenciales WiFi

// WiFiClient client;

// // OpenWeather
// String apiTemperature;
// String serverPath = OPENWEATHER_REQUEST_PATH; // Path completo con HTTP

// // ThingSpeak
// uint32_t channelNumber = SECRET_CH_ID; // Tu ID de canal en ThingSpeak
// const char *writeAPIKey = SECRET_WRITE_APIKEY; // Tu API key de escritura en ThingSpeak

// void setup() {
//     Serial.begin(115200);
//     dht.begin();
//     ThingSpeak.begin(client); // Inicializa ThingSpeak
//     connectWiFi();
//     startMillis = millis(); // Inicia el temporizador
// }

// void loop() {
//     if (millis() >= timerDuration + startMillis) {
//         temperatureData.dht = getDHTTemperatureC(); // Obtiene lectura del sensor
//         apiTemperature = getTemperatureFromAPI(); // Obtiene temperatura de la API
//         Serial.println(temperatureData.getAllTemperatureData());
//         Serial.println("Temperatura de la API: " + apiTemperature + "*C");
//         delay(50);
//         sendDataToThingSpeak();
//         startMillis = millis(); // Reinicia el temporizador
//     }
// }

// void connectWiFi() {
//     Serial.print("Esperando WiFi...");
//     WiFi.begin(ssid, password);
//     while (WiFi.status() != WL_CONNECTED) {
//         Serial.print(".");
//         delay(500);
//     }
//     Serial.println("\nWiFi Conectado");
//     Serial.println("Dirección IP: " + WiFi.localIP().toString());
// }

// void sendDataToThingSpeak() {
//     if (WiFi.status() != WL_CONNECTED) {
//         Serial.println("No se detectó conexión a Internet");
//         connectWiFi();
//     }
//     ThingSpeak.setField(1, temperatureData.dht);
//     ThingSpeak.setField(2, apiTemperature);
//     float indoorTempAverage = temperatureData.dht;
//     float outdoorTemp = apiTemperature.toFloat();
//     String status = (indoorTempAverage > 30) ? "Temperatura Relativamente Alta" :
//                    (indoorTempAverage <= 30 && indoorTempAverage >= 20) ? "Temperatura Normal" :
//                    "Temperatura Relativamente Baja";
//     ThingSpeak.setStatus(status);
//     int code = ThingSpeak.writeFields(SECRET_CH_ID, SECRET_WRITE_APIKEY);
//     if (code == 200) {
//         Serial.println("Canal de ThingSpeak actualizado correctamente.");
//     } else {
//         Serial.println("Error al actualizar canal. Código HTTP: " + String(code));
//     }
// }





