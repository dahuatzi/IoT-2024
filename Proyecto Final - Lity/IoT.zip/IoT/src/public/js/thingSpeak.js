// Reemplaza este valor con tu API key y el ID de tu campo en ThingSpeak
var apiKey = "1ZBZIVG5DFZIQD1W";
var weightField = "field1";
var channelId = "2536953";

// URL para obtener los últimos datos de ThingSpeak
var url = "https://api.thingspeak.com/channels/" + channelId + "/feeds/last.json?api_key=" + apiKey;

// Función para obtener y mostrar los datos
function getData() {
    $.getJSON(url, function(data) {
        var weight = parseFloat(data.field1); // Obtener el peso actual y convertirlo a número

        // Mostrar el peso en la página
        $("#Peso").text("Peso actual: " + weight + " kg");

        // Verificar si el peso es mayor que cero (indicando que el gato está en el arenero)
        if (weight > 0) {
            $("#estadoArenero").text("El gato está en el arenero");
        } else {
            $("#estadoArenero").text("El gato no está en el arenero");
        }
    });
}

// Llamar a la función para obtener y mostrar los datos cada 5 segundos
$(document).ready(function() {
    getData(); // Obtener datos por primera vez
    setInterval(getData, 5000); // Llamar a getData() cada 5 segundos
});



