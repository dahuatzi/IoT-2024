document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent default form submission
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    
    // Check if username and password match some predefined values
    if (username === "demo" && password === "demo123") {
        alert("Login successful!");
        // Store user information in local storage
        localStorage.setItem("loggedIn", true);
        localStorage.setItem("username", username);
        // Redirect to some page after successful login
        window.location.href = "myCat.html";
    } else {
        alert("Invalid username or password. Please try again.");
    }
});