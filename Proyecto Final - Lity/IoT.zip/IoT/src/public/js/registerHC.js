document.getElementById("registerForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent default form submission
    var username = document.getElementById("username").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    
    // Here, you can implement validation rules for username, email, and password
    
    // For demonstration purposes, let's just log the values to console
    console.log("Username:", username);
    console.log("Email:", email);
    console.log("Password:", password);
    
    // Redirect to the user profile page after successful registration
    window.location.href = "addCat.html";
});