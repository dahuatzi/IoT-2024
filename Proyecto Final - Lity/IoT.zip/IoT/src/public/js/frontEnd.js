document.addEventListener('DOMContentLoaded', function() {
    const sidenav = document.getElementById('sidenav');
    const body = document.getElementsByTagName('body')[0];

    body.addEventListener('mouseover', function() {
        sidenav.style.width = '250px';
    });

    body.addEventListener('mouseout', function() {
        sidenav.style.width = '0';
    });
});
