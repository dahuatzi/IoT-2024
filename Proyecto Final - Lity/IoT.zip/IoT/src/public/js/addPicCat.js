let imageCount = 0; // Counter to assign unique IDs to images

    function previewImage(event) {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
          const imageContainer = document.getElementById('image-container');
          const image = new Image();
          image.src = e.target.result;
          image.style.width = '100%';
          image.style.height = '100%';
          imageContainer.innerHTML = '';
          imageContainer.appendChild(image);

          // Append the image to the gallery
          const gallery = document.getElementById('gallery');
          const galleryImage = new Image();
          const imageID = ++imageCount; // Increment the counter to get a unique ID for each image
          galleryImage.src = e.target.result;
          galleryImage.setAttribute('data-image-id', imageID); // Set image ID as a data attribute
          galleryImage.onclick = function() {
            window.location.href = 'myCat.html?image_id=' + imageID; // Redirect to add_data.html with image ID
          };
          gallery.appendChild(galleryImage);
        }
        reader.readAsDataURL(file);
      }
    }