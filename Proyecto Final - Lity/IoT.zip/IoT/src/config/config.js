let dbConfig={
    user: 'danielamijares',
    password: 'KfLHxWI2xFd6r7Cg',
    dbName: 'user',
    dbUrl: function (){
         return `mongodb+srv://${this.user}:${this.password}@cluster0.vuumoit.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0`
    }
}

module.exports = dbConfig;