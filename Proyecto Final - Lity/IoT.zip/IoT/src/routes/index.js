const express = require('express');
const router = express.Router();
const path = require('path');
const mongoose = require('../db/connectBD'); 
const User = require('../db/usuarios');
const Cat = require('../db/cats')

// Ruta default
router.get('/', (req, res, next) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Ruta register
router.get('/register', (req, res, next) => {
  res.sendFile(path.join(__dirname, '../public/register.html'));
});

//escuchar datos en ruta para registrarse
const passport = require('passport');

//escuchar datos en ruta para registrarse
router.post('/register', passport.authenticate('local-signup', {
  /*mofidicar para que se vaya al perfil del usuario */
  successRedirect: '/myProfile',
  failRedirect: '/register',
  passReqToCallback: true
}));

//ruta para logearse
router.get('/login', (req, res, next)=>{
  res.sendFile(path.join(__dirname, '../Public/login.html'));
});

//escuchar datos en ruta para logearse
router.post('/login', passport.authenticate('local-login', {
  failureRedirect: '/login',  // Ensure this is correct
  failureFlash: true  // Optionally use flash messages to report login failure
}), function(req, res) {
  // Redirect or handle success case here
  res.redirect('/sandBox');
});


router.get('/logout', (req, res) => {
  req.logout(function(err) {
    if (err) {
      return next(err);
    }
    res.redirect('/');
  });
});


router.get('/myProfile', (req, res, next) => {
  res.sendFile(path.join(__dirname, '../public/myProfile.html'));
});


router.get('/myProfile', isAuthenticated,(req, res, next)=>{
  res.sendFile(path.join(__dirname, '../public/myProfile.html'));
});

router.get('/myCat', (req, res, next) => {
  res.sendFile(path.join(__dirname, '../public/myCat.html'));
});

/*router.post('/myCat', async (req, res) => {
  try {
      const newCat = new Cat({  // Make sure 'Cat' is correctly imported and is a valid constructor
          name: req.body.name,
          gender: req.body.gender,
          age: req.body.age,
          weight: req.body.weight
      });

      await newCat.save();
      res.redirect('/myCat');  // Redirect or handle response appropriately
  } catch (error) {
      console.error('Error creating new cat:', error);
      res.status(500).send('Error creating new cat');
  }
});*/


router.get('/addCat', (req, res, next) => {
  res.sendFile(path.join(__dirname, '../public/addCat.html'));
});

router.get('/sandBox', (req, res, next) => {
  res.sendFile(path.join(__dirname, '../public/sandBox.html'));
});




//Middleware
function isAuthenticated(req, res, next) {
  if(req.isAuthenticated()) {
    return next();
  }

  res.redirect('/')
}

module.exports = router;
