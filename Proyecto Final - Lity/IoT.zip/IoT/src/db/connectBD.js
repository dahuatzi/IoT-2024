const mongoose = require('mongoose');
const config = require('../config/config.js');

mongoose.connect(config.dbUrl(), {
  // Opciones adicionales de configuración de conexión si las necesitas
}).then(() => {
  console.log("connected to db");
}).catch(err => {
  console.log("not connected to db", err);
});

module.exports = mongoose;