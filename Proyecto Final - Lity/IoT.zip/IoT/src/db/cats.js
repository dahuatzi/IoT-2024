const { mongo } = require('mongoose');
const { mongoose } = require('./connectBD');

const catSchema = new mongoose.Schema({
    name: String,
    gender: String,
    age: Number,
    weight: Number,
    imagePath: String
});

module.exports = mongoose.model('cat', catSchema);