const express = require('express');
const path = require('path');
const morgan = require('morgan');
const passport = require('passport');
const session = require('express-session');
const flash = require('connect-flash');
const multer = require('multer');
const app = express();


// Database and Passport configuration
require('./src/db/connectBD');
require('./src/passport/local-auth');

// Express application settings
app.set('port', process.env.PORT || 3000);

// Serve static files from public directory
app.use(express.static(path.join(__dirname, 'src', 'public')));

// Middlewares
app.use(morgan('dev'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(session({
    secret: 'mysecretsession',
    resave: false,
    saveUninitialized: false
}));

app.use(flash());
app.use(passport.initialize());
app.use(passport.session());

// Global variables for flash messages and user info
app.use((req, res, next) => {
    app.locals.signinMessage = req.flash('signinMessage');
    app.locals.signupMessage = req.flash('signupMessage');
    app.locals.user = req.user;
    next();
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something broke!');
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Import and use routes
app.use('/', require('./src/routes/index'));


// Start the server
app.listen(app.get('port'), () => {
    console.log(`Server on port ${app.get('port')}`);
});

